<template>
    <div id="app">
        <div id="main">
            <router-view />
        </div>
        <div class="copyright">
            Copyright <a target="_blank" href="">all4you</a>
        </div>
    </div>
</template>

<style src="./assets/scss/style.scss" lang="scss"></style>
